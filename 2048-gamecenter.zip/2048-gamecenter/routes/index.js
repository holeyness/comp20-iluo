
/*
 * GET home page.
 */

exports.index = function(db) {
    return function(req, res) {
        var collection = db.get('usercollection');

        collection.find({},{sort: [['score', -1]]},function(e,docs){
            res.render('index', {
                "userlist" : docs
         });
      });
    };
};

exports.submit = function(db) {
    return function(req, res) {

        // Get our form values. These rely on the "name" attributes
        var userName = req.body.username;
        var theScore = req.body.score;
        var grid = req.body.grid;
        console.log(req.body);

       var timestamp = new Date();
        // Set our collection
        var collection = db.get('usercollection');

        //error validation
        if ((userName != "") && (theScore != "") && (grid != "") && (userName != undefined) && (typeof theScore != undefined) && (grid != undefined)){
            // Submit to the DB
            console.log("we have data");
            console.log(userName);
            console.log(theScore);
            collection.insert({
                "username" : userName,
                "score" : theScore,
                "grid" : grid,
                "created_at" : timestamp
            });            
        }
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end('thanks');
    }
}

exports.scores = function(db) {
    return function(req, res) {
        var collection = db.get('usercollection');

        console.log(req.query);
        var name = req.query["username"];

        collection.find({"username" : name},{sort: [['score', -1]]},function(e,docs){
            res.json(docs);
        });
    };
};