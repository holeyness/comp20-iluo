README.TXT
Project: 2048 Game Center 
Name: Yueming Luo

Implemented:
Node App - DONE
	Database - done
	submit.json - done
	index - done
	scores.json - done
Deployment to Heroku - Done
Rewrite 2048 - Done

Collaborated: The internet
Time taken: 8 hours

Data structure:
The game is stored as an object (everything included), in the file game_manager.js, by the function serialize.
It represents the state it's in (score, tiles etc.)


Source file modification: 
Index.html -> include jQuery library
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
So jQuery can be used

html_actuator.js: Line 28:
      $.post( "http://fast-tundra-9956.herokuapp.com/submit.json", {"username": "IanLuo", "score": metadata.score, "grid":JSON.stringify(grid)});

I placed this line here to only trigger when the game ends (and even if you keep pressing it wont retrigger), and sends the stringified grid and score to the server where it is stored (allowed cuz of CORS).